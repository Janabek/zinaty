from zaggregator.procbundle import *
from zaggregator.utils import *

name = "zaggregator"
