#!/usr/bin/env python

from zaggregator.daemon import start

if __name__ == '__main__':
    start()
